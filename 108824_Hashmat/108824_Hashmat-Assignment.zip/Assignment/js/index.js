
console.log('Application started.')

var UIController = (function () {

    var DOMString = {
        results: '.results',
        edit: '.js-edit',
        remove: '.js-remove',
        row: '.row',
        overlay: '#overlay',
        selectSize: '#select-size',
        selectQuantity: '#select-quantity',
        close: '#close',
        editOverlay: '.btn-edit'
    }

    var setSelectedIndex = function (s, v) {
        for (var i = 0; i < s.options.length; i++) {
            if (s.options[i].value == v) {
                s.options[i].selected = true;
                return;
            }
        }
    }


    return {
        getDomString: function () {
            return DOMString;
        },
        loadProducts: function (data) {
            var html, newHtml, element;
            element = DOMString.results;
            document.querySelector(element).innerHTML = '';
            data.products.forEach2(function (product) {
                console.log(product);
                newHtml = '';
                newHtml = '<div class="row" id="product-%id%""> <div class="col span-2-of-9 box"> <div class="product-image"> <img src="%image_url%" alt="%title%"> </div> </div> <div class="col span-4-of-9 box"> <div class="product-container"> <div class="product-details"> <h3>%title%</h3> <div> <span>Style #: %style%</span> </div> <div> <span>Colour:%color%</span> </div> </div> <div class="util"> <div class="shopping-bag-util"> <ul class="util-actions"> <li> <a href="#" class="js-edit">Edit</a> </li> <li> <a href="#" class="js-remove"> <span class="remove">X</span> Remove</a> </li> <li> <a href="#" class="js-save-later">Save for later</a> </li> </ul> </div> </div> </div> </div> <div class="col span-1-of-9 box"> <div class="item-size"> <span>%size%</span> </div> </div> <div class="col span-1-of-9 box"> <div class="item-quantity"> <span>%quantity%</span> </div> </div> <div class="col span-1-of-9 box"> <div class="item-price"> <span class="price-symbol"> <sup>&#36;</sup> </span> <span class="price"> %price%</span> </div> </div> </div>';
                //newHtml = '<div class="row" id="product-%id%"> <div class="col span-3-of-9 box"> <figure class="product"> <img src="%image_url%" alt="Korean bibimbap with egg and vegetables"> </figure> </div> <div class="col span-3-of-9 box"> <div class="product-container"> <div class="product-details"> <h3>%title%</h3> <div> <span>Style #: %style%</span> </div> <div> <span>Colour:%color%</span> </div> </div> <div class="util"> <div class="shopping-bag-util"> <ul class="util-actions"> <li> <a href="#" class="js-edit">Edit</a> </li> <li> <a href="#" class="js-remove">Remove</a> </li> <li> <a href="#" class="js-save-later">Save for later</a> </li> </ul> </div> </div> </div> </div> <div class="col span-1-of-9 box"> <span>%size%</span> </div> <div class="col span-1-of-9 box shopping-bag-qty"> <span>%quantity%</span> </div> <div class="col span-1-of-9 box item-price"> <span class="price-symbol"> <sup>&#36;</sup> </span> <strong> <span class="price"> %price%</span> </strong> </div> </div>';
                newHtml = newHtml.replace("%id%", product.id);
                newHtml = newHtml.replace('%image_url%', product.image_url);
                newHtml = newHtml.replace('%title%', product.title);
                newHtml = newHtml.replace('%title%', product.title);
                newHtml = newHtml.replace('%style%', product.style);
                newHtml = newHtml.replace('%color%', product.color);
                newHtml = newHtml.replace('%size%', product.size);
                newHtml = newHtml.replace('%quantity%', product.quantity);
                newHtml = newHtml.replace('%price%', product.price);
                document.querySelector(element).insertAdjacentHTML("beforeend", newHtml);
            })
        },
        remove: function (id) {
            var element = document.getElementById(id);
            element.parentNode.removeChild(element);
        },
        showOverLay: function (prod) {
            setSelectedIndex(document.querySelector(DOMString.selectSize), prod.size);
            setSelectedIndex(document.querySelector(DOMString.selectQuantity), prod.quantity);
            document.querySelector(DOMString.editOverlay).setAttribute('id', prod.id);
            document.querySelector(DOMString.overlay).style.display = "block";
        },
        closeOverLay: function () {
            document.querySelector(DOMString.overlay).style.display = "none";
        }
    }
})();

var ProductController = (function () {

    var shoppingBag;

    var ShoppingBag = function (data) {
        this.promoCode = data.promoCode;
        this.promoCodeValue = data.promocode_value;
        this.products = data.products;
        this.data = data;
    }

    ShoppingBag.prototype.remove = function (id) {
        var index, product;
        index = getIndex(id);
        this.products.splice(index, 1);
    }

    ShoppingBag.prototype.update = function (prod) {
        var index, product;
        index = getIndex(prod.id);
        product = shoppingBag.products[index];
        product.size = prod.size;
        product.quantity = prod.quantity;
    }

    var getIndex = function (id) {
        var index, product;
        for (var i = 0; i < shoppingBag.products.length; i++) {
            product = shoppingBag.products[i];
            if (product.id == id) {
                index = i;
                break;
            }
        }
        return index;
    }

    return {
        getProductInfo: function () {
            return getJSON().data;
        },
        remove: function (id) {
            shoppingBag.remove(id);
        },
        InitializeShoppingBag: function (data) {
            shoppingBag = new ShoppingBag(data);
        },
        updateShoppingBag: function (prod) {
            shoppingBag.update(prod);
        },
        getProductById: function (id) {
            var index;
            index = getIndex(id);
            return shoppingBag.products[index];
        },
        getShoppingBag: function () {
            return shoppingBag;
        }
    }

})();

var controller = (function (productCtrl, uiCtrl) {

    var DOMString = uiCtrl.getDomString();

    //Get JSON Data
    var getJSONData = function () {
        var json = '{"data":{"promoCode":"JF10","promocode_value":"7.00","products":[{"id":"1","title":"Solid green cotton tshirt","style":"MS13KT1906","color":"Blue","size":"M","quantity":"1","price":"11.00","dicounted_price":"","discount":"false","image_url":"./img/product1.png"},{"id":"2","title":"Pink Rainbow print girls tee","style":"MS13KT1906","color":"Gray","size":"S","quantity":"2","price":"17.00","dicounted_price":"","discount":"false","image_url":"./img/product2.png"},{"id":"3","title":"Blue Flower pattern shirt","style":"MS13KT1906","color":"Blue","size":"S","quantity":"1","price":"21.00","dicounted_price":"09.00","discount":"true","image_url":"./img/product3.png"}]}}';
        return JSON.parse(json).data;
    }

    //Attach event listners for DOM elements
    var setupEventListener = function () {
        var DOMString = uiCtrl.getDomString();

        //For remove buttons
        Array.from(document.querySelectorAll(DOMString.remove)).forEach2(function (el) {
            el.addEventListener('click', deleteItem);
        });


        //For edit buttons
        Array.from(document.querySelectorAll(DOMString.edit)).forEach2(function (el) {
            el.addEventListener('click', editItem);
        });

        //For close button inside overlay
        document.querySelector(DOMString.close).addEventListener('click', function () {
            var overlay = document.querySelector(DOMString.overlay);
            uiCtrl.closeOverLay();
        });

        //For closing overlay clicking anywhere on the window
        window.onclick = function (event) {
            var overlay = document.querySelector(DOMString.overlay);
            if (event.target == overlay) {
                uiCtrl.closeOverLay();
            }
        };

        //For edit button inside overlay
        document.querySelector(DOMString.editOverlay).addEventListener('click', function () {
            var productId, prod, shoppingBag;
            productId = document.querySelector(DOMString.editOverlay).getAttribute('id');
            prod = productCtrl.getProductById(productId);
            prod.size = document.querySelector(DOMString.selectSize).value;
            prod.quantity = document.querySelector(DOMString.selectQuantity).value;
            productCtrl.updateShoppingBag(prod);
            uiCtrl.loadProducts(productCtrl.getShoppingBag());
            setupEventListener();
            uiCtrl.closeOverLay();
        });
    };

    //Remove item from the product list
    var deleteItem = function (event) {
        var id;
        id = getProductId(event);
        productCtrl.remove(id.split('-')[1]);
        uiCtrl.remove(id);
    };

    //Show overlay item on clicking edit buttons
    var editItem = function (event) {
        var id, prod;
        id = getProductId(event);
        prod = productCtrl.getProductById(id.split('-')[1])
        uiCtrl.showOverLay(prod);
    };

    //Get the product id on clicking edit/remove buttons
    var getProductId = function (event) {
        var id, element;
        element = event.target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
        return element.id;
    }

    var initArrayExtensions = function () {
        Array.prototype.forEach2 = function (callback) {
            for (var i = 0; i < this.length; i++) {
                callback(this[i]);
            }
        }
    }


    return {
        init: function () {

            //0. Initialize array extension
            initArrayExtensions();

            //1. Parse the json data
            var data = getJSONData();
            productCtrl.InitializeShoppingBag(data);

            //2. Load Product data
            uiCtrl.loadProducts(data);

            //Setup Event Listeners
            setupEventListener();
        }
    }

})(ProductController, UIController);

controller.init();