//PRODUCT CONTROLLER

var productController = (function() {
    
    var product, data;
    
    product = function(id,img, desc, style, color, size, quantity, price) {
      
        this.id= id;
        this.image = img;
        this.productTitle = desc;
        this.style = style;
        this.color = color;
        this.size = size;
        this.quantity = quantity;
        this.price = price;
    };
    
    data = {
        selectedProduct: [],
        subTotal: 0,
        estimatedTotal: 0
    };
    
    
   var calculateTotalAmount = function() {
        var totalAmount = 0;
        data.selectedProduct.forEach(prod => {
            totalAmount += parseFloat(prod.price) * parseInt(prod.quantity);
        });  
        
        data.subTotal = totalAmount;
        
        data.estimatedTotal = totalAmount;
        
        return {
            subTotal: data.subTotal,
            estimatedTotal: data.estimatedTotal
        }
    };
    
    
    
    return {
        
        GetProductListBag: function() {            
            data.selectedProduct.push(new product(1, './resources/img/img-1.jpg', 'Solid Green Cotton Tshirt', 'MS13kt1906', 'Blue', 'S', 1, 11));
            data.selectedProduct.push(new product(2, './resources/img/img-2.jpg', 'Pink Rainbow Print Girls Tee', 'MS13kt1906', 'Gray', 'S', 1, 17));
            data.selectedProduct.push(new product(3,  './resources/img/img-3.jpg', 'Blue Flower Pattern shirt', 'MS13kt1906', 'Blue', 'S', 1, 09));       
       
            calculateTotalAmount();
        },
       
        getDefaultProducts: function(){
            var items = [];
            data.selectedProduct.forEach(pr => items.push(pr));
            
            return items;
        },
        
        updatedPrices: function() {
            return calculateTotalAmount();            
        },
        
        deleteItem: function(id) {
            var ids, index;
            ids = data.selectedProduct.map(function(current) {
                return current.id;
            });
            
            index = ids.indexOf(parseInt(id));
            
            if (index !== -1){
                data.selectedProduct.splice(index, 1);
                return data;
            }
        },
        
        getProductById: function(id){
            var product;
            
            data.selectedProduct.forEach(pr => {
                if(pr.id === parseInt(id)){
                    product = pr;
                }   
                
            });
            
            return product;
        },
        
        getAllProducts: function() {
            return data.selectedProduct;
        }
    };
})();


//UI CONTROLLER

var UIController = (function() {
    
    var DOMStrings = {
      
        productItemsList: "product-items-list",
        productItemsListContainer: ".product-items-list",
        subTotal: ".text_sub_total",
        estimatedTotal: ".text_estimatedTotal",
        txtEdit: "edit_",
        txtRemove: "remove_",
        txtSave: "save_",
        overlayContainer: ".overlay",
        overlayClose: ".close",
        overlayEditSave: ".btn_edit_product",
        elPrColorName: ".pr-colorName",
        elPrDesc: ".pr-desc",
        elPrPrice: ".pr-price",
        elPrImageLarge: ".pr-img-large",
        elSelectSize: "select_size",
        elSelectQuantity: "select_quantity"
    };
    
    return {
                  
     addheaderItem: function(numberOfItems) {
        var html, newHtml, element, price;
        // Create header HTML string with placeholder text
        
       html = '<div class="row row-header row-border"><div class="col span-1-of-6 col-div">%itemsCount% ITEMS</div><div class="col span-2-of-6 col-desc">&nbsp;</div><div class="col span-1-of-6 col-div">SIZE</div><div class="col span-1-of-6 col-div">QTY</div><div class="col span-1-of-6 col-div">PRICE</div>';
                
        //Replace the placeholder text with correct data
        newHtml = html.replace('%itemsCount%', numberOfItems);
               
        element = document.getElementById(DOMStrings.productItemsList);
            
            if(element !== undefined){
                element.insertAdjacentHTML('afterbegin',newHtml);
            }
    },
        
     addProductItem: function(obj) {
        var html, newHtml, element, price;
        // Create product items HTML string with placeholder text
        
        html ='<div class="row clearfix"><div><div class="col span-1-of-6 col-div"><img src="%image%"></div><div class="col span-2-of-6 col-desc"><h2>%productTitle%</h2><p class="row-style">Style #: %style%<br> Color: %color%</p><div class="buttons"><a href="#" id="%edit_id%">EDIT</a> &#124; <a href="#" id="%remove_id%">X REMOVE</a> &#124;<a href="#" id="%save_id%">SAVE FOR LATER</a></div></div><div class="col span-1-of-6 col-div"><h3>%size%<h3></div> <div class="col span-1-of-6 col-div"><h3><input type="text" value="%quantity%" id="qty_%id%"></h3></div><div class="col span-1-of-6 col-div"><h3><span class="currency-symbol">$</span><span class="productPrice_%id%">%price%</span></h3></div></div>';
        
        price = parseFloat(obj.price) * parseInt(obj.quantity);
        
        //Replace the placeholder text with correct data
        newHtml = html.replace('%id%', obj.id);
        newHtml = newHtml.replace('%image%', obj.image);
        newHtml = newHtml.replace('%productTitle%', obj.productTitle);
        newHtml = newHtml.replace('%style%', obj.style);
        newHtml = newHtml.replace('%color%', obj.color);
        newHtml = newHtml.replace('%size%', obj.size);
        newHtml = newHtml.replace('%quantity%', obj.quantity);
        newHtml = newHtml.replace('%price%', price);
        newHtml = newHtml.replace('%edit_id%', DOMStrings.txtEdit + obj.id);
        newHtml = newHtml.replace('%remove_id%', DOMStrings.txtRemove + obj.id);
        newHtml = newHtml.replace('%save_id%', DOMStrings.txtsave + obj.id);
        
        element = document.getElementById(DOMStrings.productItemsList);
            
            if(element !== undefined){
                element.insertAdjacentHTML('beforeend',newHtml);
            }
     },
     
     clearDisplay: function() {
            element = document.getElementById(DOMStrings.productItemsList);
            while (element.firstChild) {
                element.removeChild(element.firstChild);
            }         
     },
        
     displayPrice: function(obj){
            document.querySelector(DOMStrings.subTotal).textContent = obj.subTotal;
            document.querySelector(DOMStrings.estimatedTotal).textContent = obj.estimatedTotal;
            
        },
    
        noProductsExist: function() {
            element = document.getElementById(DOMStrings.productItemsList);
            
         var newHtml = '<div class="row row-header row-border"><div class="col span-6-of-6 no-items">PRODUCT ITEMS ARE UNAVAILABLE</div></div>';
            
            if(element !== undefined){
                element.insertAdjacentHTML('afterbegin',newHtml);
            }
        },
           
        displayProductDetails: function(obj){
            
            document.querySelector(DOMStrings.elPrDesc).textContent = obj.productTitle.toUpperCase();
            document.querySelector(DOMStrings.elPrImageLarge).childNodes[1].src = obj.image;
            document.querySelector(DOMStrings.elPrColorName).textContent = obj.color.toUpperCase();
            document.querySelector(DOMStrings.elPrPrice).textContent = obj.price;
            document.getElementById(DOMStrings.elSelectSize).value = obj.size;
            document.getElementById(DOMStrings.elSelectQuantity).value = obj.quantity;
            document.querySelector(DOMStrings.overlayEditSave).value = obj.id;           
        },
        
        displayOverlay: function () {
            document.querySelector(DOMStrings.overlayContainer).style.display = 'block';
        },
        
        hideOverlay: function () {
            document.querySelector(DOMStrings.overlayContainer).style.display = 'none';
        },
        
     getDOMString: function(){
            return DOMStrings;
     }
    
    };
})();



//GLOBAL CONTROLLER

var controller = (function(productCtrl, UICtrl) {
       var DOM = UICtrl.getDOMString(),
              
    getProducts = function() {
        var products = productCtrl.getDefaultProducts();
        reloadPage(products);
    },
           
   reloadPage = function(products) {
        
        UICtrl.clearDisplay();
        
       if(products.length > 0) {
           UICtrl.addheaderItem(products.length);
            products.forEach(prod => {

                UICtrl.addProductItem(prod);
            });
           
       } else {
           UICtrl.noProductsExist();
       }
       
       var price = productCtrl.updatedPrices();
       UICtrl.displayPrice(price);
   },
   
   deleteProductItem = function(event) {
       var itemID, productId;
       
       itemID = event.target.id;
     
       if(itemID.indexOf(DOM.txtRemove) != -1) {   
           productId = itemID.replace(DOM.txtRemove, '');
            var data =  productCtrl.deleteItem(productId);
          
           reloadPage(data.selectedProduct);
       }
   },
    
    editProductItem = function(event) {
        var itemID, productId;
        
        itemID = event.target.id;
        
        if(itemID.indexOf(DOM.txtEdit) != -1) {
            productId = itemID.replace(DOM.txtEdit, '');
            var product = productCtrl.getProductById(productId);        

            UICtrl.displayProductDetails(product);

            UICtrl.displayOverlay();
        }
    },
    
    closePopupItem = function() {            
        UICtrl.hideOverlay();
    },
           
   setupEventListeners = function() {
        document.querySelector(DOM.productItemsListContainer).addEventListener('click', deleteProductItem);
        document.querySelector(DOM.productItemsListContainer).addEventListener('click', editProductItem);
        document.querySelector(DOM.overlayClose).addEventListener('click', closePopupItem);
       
    }
    
    return {
        init: function() {
            productCtrl.GetProductListBag();
            getProducts();
            setupEventListeners();
            productCtrl.updatedPrices();
        }
    };
        
})(productController, UIController);

controller.init();